/*
 *  @(#)Colecciones.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

 
package fp2.poo.practica10.colecciones;

import fp2.poo.practica10.utilidades.Figura;
import fp2.poo.practica10.utilidades.Rectangulo;
import fp2.poo.practica10.utilidades.Circulo;
import fp2.poo.practica10.utilidades.Cuadrado;
import fp2.poo.practica10.utilidades.OtroCirculo;
import fp2.poo.practica10.utilidades.OtroCuadrado;

import fp2.poo.practica10.utilidades.OrdenacionArea;
import java.awt.Color;

import java.util.Collections; 
import java.util.List;
import java.util.ArrayList; 
import java.util.Iterator; 

import java.io.IOException;

/**
 * Descripcion: La clase Colecciones implementa el ejemplo de manejo  
 *              de colecciones, concretamente con un ArrayList.
 *
 * @version 1.0 Marzo 2016
 * @author  Fundamentos de Programacion II
 */
public class Colecciones {
    public static void main (String args[]) {	
        /*
         * Este ejemplo utiliza una colección de tipo ArrayList, 
         * que es una implementación de la interfaz List.
         */
        List<Figura> serieDeFiguras = new ArrayList<Figura>();
        
        /*********************************************************
         ********COMPROBACIÓN DE QUE ESTÁ VACÍA: isEmpty   *******
         *********************************************************/
        System.out.println("\n************************************");
        System.out.println( "Se ha creado la coleccion (ArrayList)"); 
        System.out.println( "Se comprueba que esta vacia.       ");
        System.out.println("************************************\n");
        if(serieDeFiguras.isEmpty())
            System.out.println("NO hay elementos en la coleccion.\n");
        else
            System.out.println("SI hay elementos en la coleccion.\n");
        pausa();

        /*********************************************************
         ********AÑADIR ELEMENTOS A LA COLECCIÓN: add    *********
         *********************************************************/	
	    /*
         * Se crean dos objetos del tipo Cuadrado y se añaden a la lista.
         */
        Figura cuad1 = new Cuadrado (3.5f,Color.ORANGE);
        Figura cuad2 = new Cuadrado (2.2f,Color.YELLOW);
        serieDeFiguras.add (cuad1);
        serieDeFiguras.add (cuad2);

        /***********************************************************
         ******** COMPROBACIÓN DE QUE NO ESTÁ VACÍA: isEmpty *******
         ******** SE MUESTRA EL NÚMERO DE ELEMENTOS: size   ********
         ***********************************************************/	

        System.out.println("\n************************************");
        System.out.println( "EJEMPLO: acabo de meter dos elementos,"); 
        System.out.println( "Se comprueba que no esta vacia.       ");
        System.out.println("************************************\n");

        if(serieDeFiguras.isEmpty())
	        System.out.println("NO hay elementos en la coleccion");
        else
	        System.out.println("SI hay elementos en la coleccion, concretamente "
                               + serieDeFiguras.size()+"\n");    
        pausa();

       /* 
        * Se crea un nuevo cuadro del tipo OtroCuadrado y se añade a la lista.
        */
        Figura cuad3 = 	new OtroCuadrado (8.9f,"AMARILLO SERENIDAD");
        serieDeFiguras.add (cuad3);
		
       /* 
        * Se crea un círculo del tipo Circulo y se añade a la lista.
        */
        serieDeFiguras.add (new Circulo (3f, Color.BLACK));
		

       /* 
        * Se crea un círculo del tipo OtroCirculo y se añade a la lista.
        */
        serieDeFiguras.add (new OtroCirculo (4f,"MELOCOTON MADURO")); 
		
       /* 
        * Se crean dos rectángulos del tipo Rectangulo y se añaden a la lista.
        */
        serieDeFiguras.add (new Rectangulo (2f, 3f, "CUARZO ROSA"));
        serieDeFiguras.add (new Rectangulo (12f, 3f,"LILA GRIS"));


        /*************************************************************
         ********              Trabajo a realizar.             *******
         ********              ==================              *******
         ******** EJERCICIO 1: INSTANCIE 3 FIGURAS             *******
         ********              - Rectángulo Negro.             *******
         ********              - OtroCírculo Negro.            *******
         ********              - OtroCuadrado Blanco.          *******
		 ********              añadir a la colección           ******* 
         ********              y mostrar por pantalla.         *******
         *************************************************************/











        /*************************************************************
         ********    Se muestra toda la coleccion.             *******
         ********    toString                                  *******
         ********                                              *******
         ************************************************************/
	 
        System.out.println("\n*************************************");
        System.out.println( "EJEMPLO: Se han insertado las figuras."); 
        System.out.println( "Se muestran por pantalla.             ");
        System.out.println("************************************\n");

        System.out.println( serieDeFiguras.toString());

        System.out.println( "Numero total de figuras: " + serieDeFiguras.size()); 
        System.out.println();
        pausa();

        /********************************************************************
         ******** Extracción de un objeto de la colección:            *******
         ********              - remove                               *******
         ********                                                     *******
         ******** Se muestra la primera ocurrencia de un objeto:      *******
         ********              - indexOf                              *******
         ********                                                     *******
         ******** Se muestra el objeto de una posición: get           *******
         ********              - get                                  *******
         ********************************************************************/

        /********************************************************************
         ******** EJEMPLO: Se comprueba si cuad3 esta en la colección. ******
         ********          Se borra, y se vuelve a comprobar.          ******
         ********************************************************************/

        System.out.println("\n****************************************************");
        System.out.println( "EJEMPLO: Se busca un objeto usando su referencia,  *");
        System.out.println( "         y se muestra su posicion.                 *");
        System.out.println("*****************************************************\n");

        if(serieDeFiguras.contains(cuad3))
            System.out.println(cuad3
			                  + " SI pertenece a la coleccion y esta en la posicion "
			                  + serieDeFiguras.indexOf(cuad3)+"\n\n");
        else
            System.out.println(cuad3 + " NO pertenece a la coleccion\n\n");
        pausa();

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: Se borra el elemento usando su referencia, *");
        System.out.println(  "         y se vuelve a buscar.                      *");
        System.out.println(  "*****************************************************\n");

        serieDeFiguras.remove(cuad3);
        if(serieDeFiguras.contains(cuad3))
            System.out.println(cuad3 
			                 + " SI pertenece a la coleccion y esta en la posicion "
							 + serieDeFiguras.indexOf(cuad3)+"\n\n");
        else
            System.out.println(cuad3+" NO pertenece a la coleccion\n\n");
        pausa();
       
        /*****************************************************************
         ********              Trabajo a realizar.                 *******
         ********              ==================                  *******
         ******** EJERCICIO 2: VUELVA A AÑADIR cuad3               *******
         ********             -Repita la operacion de busqueda     *******
         ********              con los mismos mensajes anteriores. *******
         ********             -Observe la posición de la figura    *******
         ********              (antes y después)                   *******
         ********             - ¿Qué ha ocurrido?                  *******
         ********             - ¿Quién ocupa ahora la posicion 2?  *******
         *****************************************************************/

	







        /********************************************************************
         ******** Objectos duplicados de la colección:                *******
         ********              - lastIndexOf                          *******
         ********                                                     *******
         ********  Se muestra la posición de la última ocurrencia.    *******
         ********************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: Elementos duplicados.                      *");
        System.out.println(  "         -Se vuelve a insertar cuad3,               *");
        System.out.println(  "          el objeto esta dos veces                  *");
        System.out.println(  "*****************************************************\n");
       
        serieDeFiguras.add (cuad3);
        if(serieDeFiguras.contains(cuad3)) {
	    System.out.println(cuad3
		                       + " esta en la posicion "+serieDeFiguras.indexOf(cuad3)
                               + " y tambien esta en la posicion "
                               + serieDeFiguras.lastIndexOf(cuad3) + "\n\n");
        }else{
            System.out.println(cuad3+" NO pertenece a la coleccion\n\n");
        }
        pausa();

        /********************************************************************
         ******** Se recorre la colección con bucle for-each:         *******
         ********                                                     *******
         ********************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: Uso de bucle for-each, para imprimir       *");
        System.out.println(  "         las figuras por pantalla.                  *");
        System.out.println(  "*****************************************************\n");

        System.out.println("Listado de la coleccion:\n");
        for (Figura fig : serieDeFiguras) {
            System.out.print("\t"+ fig);
        }
        System.out.println();
        pausa();

        /********************************************************************
         ********              Trabajo a realizar.                    *******
         ********              ==================                     *******
         ******** EJERCICIO 3: MUESTRE POR PANTALLA SÓLO LOS COLORES. *******
         ********             -Use el bucle for-each.                 *******
         ********              para mostrarlos por pantalla           *******
         ********                                                     *******
         ********************************************************************/






    



        /********************************************************************
         ******** Ejemplo 2: Se calcula el área total de las          *******
         ********            figuras de la colección,                 *******
         ********            de la misma forma.                       *******
         ********************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO 2: Uso de bucle for-each, para calcular     *");
        System.out.println(  "           el area total.                           *");
        System.out.println(  "*****************************************************\n");

        float areaTotal = 0.f;

        for (Figura tmp: serieDeFiguras) {      
		    areaTotal = areaTotal + tmp.getArea();     
		}

        System.out.println ( "Tenemos un total de " + serieDeFiguras.size() 
                           + " figuras y su area total es de "  
                           + areaTotal + " uds cuadradas");
        pausa();

        /**********************************************************************
         ********              Trabajo a realizar.                      *******
         ********              ==================                       *******
         ******** EJERCICIO 4: CACULE EL PERIMETRO TOTAL DE LAS FIGURAS *******
         ********              DE LA COLECCIÓN USANDO EL BUCLE for-each *******
         ********              para mostrarlo por pantalla              *******
         ********                                                       *******
         **********************************************************************/
		







	
	
	

        /********************************************************************
         ******** Ejemplo 2: Recorrer la colección con un iterador:   *******
         ********            Iterator                                 *******
         ********                                                     *******
         ********************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: Se obtiene un iterador y se muestran       *");
        System.out.println(  "         los objetos.                               *");
        System.out.println(  "*****************************************************\n");

        Iterator<Figura> iterador=serieDeFiguras.iterator();
        while(iterador.hasNext()){
            System.out.print(iterador.next());
        }
        pausa();
		
        /**********************************************************************
         ********              Trabajo a realizar.                      *******
         ********              ==================                       *******
         ******** EJERCICIO 5: MOSTRAR POR PANTALLA EL ÁREA DE CADA     *******
         ********              FIGURA DE LA COLECCIÓN, USANDO UN        *******
         ********              ITERADOR.                                *******
         ********              CUENTELAS Y MUESTRELO POR PANTALLA.      *******
         **********************************************************************/










        /*************************************************************************
         ******** USO DE ALGORITMOS GENÉRICOS, Y FUNCIONES DE Collections  *******
         ********      Cambio del orden de una colección:                  *******
         ********             - reverse                                    *******
         *************************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: uso el algoritmo sort para dar la vuelta   *");
        System.out.println(  "         a la colección.                            *");
        System.out.println(  "*****************************************************\n");
      
        System.out.println("Orden original \n"+serieDeFiguras);
        Collections.reverse(serieDeFiguras);
        System.out.println("\nNuevo Orden \n"+serieDeFiguras);
        pausa();

        /*************************************************************************
         ********   CAMBIO DE ORDEN DE UNA COLECCIÓN: Comparator           *******
         ********         La clase OrdenacionArea esta en "utilidades"     *******
         ********         Implementa un comparador de figuras por área     *******
         *************************************************************************/

        System.out.println("\n*****************************************************");
        System.out.println(  "EJEMPLO: Uso de comparador personalizado.           *");
        System.out.println(  "         Realiza la ordenacion por area             *");
        System.out.println(  "         de mayor a menor.                          *");
        System.out.println(  "*****************************************************\n");
      
        OrdenacionArea ordenador=new OrdenacionArea();
        Collections.sort(serieDeFiguras,ordenador);
        System.out.println("\nAhora ordenadas por Area, de mayor a menor \n");
        for (Figura tmp: serieDeFiguras) {      
           System.out.println(tmp+": Area= "+tmp.getArea());     
        }

        /**********************************************************************
         ********              Trabajo a realizar.                      *******
         ********              ==================                       *******
         ******** EJERCICIO 6: Implemente un Comparador para ordenar    *******
         ********              por el perímetro de menor a mayor.       *******
         ********              Uselo para ordenar la colección y        *******
         ********              muestre por pantalla el perimetro de     *******
         ********              cada figura.                             *******
         **********************************************************************/







        /**********************************************************************/
        /**********************************************************************/
        /**********************************************************************/     
    }
    private static void pausa(){
        try{
            System.out.println("Pulse intro para continuar");
            System.in.read();
        }catch(IOException exc){
            System.err.println(exc+"Error al leer\n\n");
        }
	}
}