/*
 *  @(#)package-info.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * fp2.poo.practica10.utilidades 
 *
 * Este paquete Proporciona proporciona la clase principal para la práctica 
 * de colecciones.
 */
package fp2.poo.practica10.colecciones;

