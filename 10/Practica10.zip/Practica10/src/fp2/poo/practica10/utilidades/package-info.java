/*
 *  @(#)package-info.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * fp2.poo.practica10.utilidades 
 *
 * Proporciona la interfaz Figura, la clase abstracta MiFigura y un conjunto de
 * implementaciones útiles para el desarrollo de la práctica de colecciones. 
 * También la clase OrdenacionArea que se utilizará para ordenar las 
 * figuras de mayor a menor área.
 */
package fp2.poo.practica10.utilidades;

