/*
 *  Fichero: Almacen.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


package fp2.poo.practica11;

import java.util.HashMap; 
import java.util.Iterator;

/**
 * Descripcion: Esta es una clase es un ejemplo de HashMap.
 *              Un almacén contiene una colección de productos
 *              identificados por un código de producto 
 *              
 *
 * @version version 1.0 Abril 2016
 * @author  Fundamentos de Programacion II
 */
public class Almacen {

    /** Atributo privado donde se almacenan los productos del almacén. */
    private HashMap<String,Float> productos;

    /**
     *  Constructor de la clase Almacén.
     *
     *  Parametros: No hay parámetros.
     */
    public Almacen() {
        // Crea el HashMap para la lista de productos
        this.productos = new HashMap<String,Float>();; 
    }

     /**
     *   Indica si un producto existe en el almacén
     */
    public boolean existeProducto(String codigo){
    
       boolean resultado = false;
       if (productos.containsKey(codigo)){
           resultado = true;
       }
       
       return resultado;
    }
    
    /**
     *  Guarda un producto en el almacén
     */
    public void guardaProducto(String codigo, float precio){
    
         if (productos.containsKey(codigo)){
            System.out.println("No se puede introducir el producto. El codigo esta repetido.");
         }
         else{
            productos.put(codigo, precio);               
         }
    
    }
    
    /**
     *  Modifica el precio de un producto del almacén
     */
    public void modificaPrecio(String codigo, float precio){
      
         if (productos.containsKey(codigo)){
             productos.put(codigo, precio);            
         }
         else{
            System.out.println("\nNo hay ningun producto con ese codigo.");
         }

    }

    /**
     *  Muestra los productos del almacén
     */
    public void muestraProductos(){
    
        String clave;
        Iterator<String> iteradorProductos 
                             = productos.keySet().iterator();
        
        System.out.println("\nHay los siguientes productos en el almacen:");
        while(iteradorProductos.hasNext()){
            clave = iteradorProductos.next();
            System.out.println(clave + " - " + productos.get(clave));
        }        
   
    }

    /**
     *  Elimina un producto del almacén
     */
    public void eliminaProducto(String codigo){
    
        if (productos.containsKey(codigo)){
            productos.remove(codigo);
        }
        else{
            System.out.println("No hay ningun producto con ese codigo.");  
        }       
    
    }
}
