/*
 *  Fichero: GestorAlmacen.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


package fp2.poo.practica11;

import java.util.Scanner;

/**
 * Descripción: Esta es una clase de ejemplo para presentar
 *              los HashMap.
 *
 * @version version 1.0 Abril 2016
 * @author  Fundamentos de Programacion II
 */
public class GestorAlmacen {

    /**
     *  Este metodo es el método principal de la aplicación
     *  Crea un objeto del tipo Almacen y realiza operaciones sobre él
     */
    public static void main( String args[] ) {
 
 
      Almacen almacenDeProductos = new Almacen();
      Scanner sc = new Scanner(System.in);
      int opcionElegida = 0;
      float precio;
      String codigo;

      while (opcionElegida != 5){
          System.out.println("\nIntroduce el numero de la opcion que quieras:");
          System.out.println("1.- Introducir producto");
          System.out.println("2.- Modificar precio");
          System.out.println("3.- Mostrar todos los productos");
          System.out.println("4.- Eliminar producto");
          System.out.println("5.- Salir\n");
          opcionElegida = sc.nextInt();

          switch (opcionElegida){
              case 1:
                  System.out.println("Introduce el codigo del producto:");
                  codigo = sc.next();
                  System.out.println("Introduce el precio del producto:");
                  precio = sc.nextFloat();
                  almacenDeProductos.guardaProducto(codigo, precio);
                  break;
              case 2:
                  System.out.println("Introduce el codigo del producto del que quieres cambiar el precio:");
                  codigo = sc.next();
                  if (almacenDeProductos.existeProducto(codigo)){
                     System.out.println("Introduce el precio del producto:");
                     precio = sc.nextFloat();            
                     almacenDeProductos.modificaPrecio(codigo, precio);
                  }
                  else{
                     System.out.println("No hay ningun producto con ese codigo.");
                  }

                  break;
              case 3:
                  almacenDeProductos.muestraProductos();
                  break;
              case 4:
                  System.out.println("Introduce el codigo del producto que quieres eliminar:");
                  codigo = sc.next();
                  almacenDeProductos.eliminaProducto(codigo);
                  break;
              case 5:
                  break;   // Si la opcion es 5 no se hace nada 
              default:
                  System.out.println("Tienes que introducir una opcion valida");
          }

      }
	
  }
 
}
