/*
 *  Fichero: Empleado.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


package fp2.poo.empresa;

import fp2.poo.empresa.Persona;


/**
 * Descripcion: Esta es una clase que representa un empleado de la empresa 
 *
 * @version version 1.0 Mayo 2011
 * @author  Fundamentos de Programacion II
 */
public class Empleado implements Persona {

    /** nombre es el atributo asociado al nombre                   */
    private String nombre;

    /** primerApellidoes el atributo asociado al primer apellido   */
    private String primerApellido;

    /** segundoApellidoes el atributo asociado al segundo apellido */
    private String segundoApellido;

    /** DNI es el atributo asociado a la identificacion           */
    private String DNI;

    /** domicilio es el atributo asociado al domicilio            */
    private String domicilio;

    
    /*
     *  Descripcion: Constructor de la clase.          
     */
    public Empleado ( String nombre,          String primerApellido,
                     String segundoApellido, String dni,  
                     String domicilio ) {
        this.nombre          = nombre;
        this.primerApellido  = primerApellido;
        this.segundoApellido = segundoApellido;
        this.DNI             = dni;
        this.domicilio       = domicilio;
    }
    
    /*
     *  Descripcion: Metodo getter de nombre.          
     */
    public String getNombre( ){
        return this.nombre;
    }

    /*
     *  Descripcion: Metodo getter del primer apellido.          
     */
    public String getPrimerApellido( ){
        return this.primerApellido;
    }

    /*
     *  Descripcion: Metodo getter del segundo apellido.          
     */
    public String getSegundoApellido( ){
        return this.segundoApellido;
    }

    /*
     *  Descripcion: Metodo getter del dni.          
     */
    public String getDNI( ){
        return this.DNI;
    }

    /*
     *  Descripcion: Metodo getter del domicilio.          
     */
    public String getDomicilio( ){
        return this.domicilio;
    }

    /*
     *  Descripcion: Metodo setter del nombre.          
     */
    public void setNombre( String nombre ){
        this.nombre = nombre;
    }

    /*
     *  Descripcion: Metodo setter del primerApellido.          
     */
    public void setPrimerApellido(  String primerApellido ){
        this.primerApellido  = primerApellido;
    }

    /*
     *  Descripcion: Metodo setter del segundoApellido .          
     */
    public void setSegundoApellido( String segundoApellido ){
        this.segundoApellido = segundoApellido;
    }

    /*
     *  Descripcion: Metodo setter del DNI.          
     */
    public void setDNI( String dni ){
        this.DNI  = dni;
    }

    /*
     *  Descripcion: Metodo setter del domicilio.          
     */
    public void setDomicilio( String domicilio ){
        this.domicilio  = domicilio;
    }
}
