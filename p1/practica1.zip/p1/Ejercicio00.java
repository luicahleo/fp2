public class Ejercicio00 {
    public static void main( String args[] ) {
        System.out.println( "El programa se ha ejecutado." );
    }
}