/*
 *  Fichero: Ejercicio00.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 *  Sin copyright
 */

package fp2.poo.practica1;

import java.lang.*;


/**
 * Descripcion: Esta una clase de ejemplo para presentar
 *              las unidades de compilacion.
 * @version version 1.0 Abril 2011
 * @author  Fundamentos de Programacion II
 */
public class Ejercicio00 {
    public static void main( String args[] ) {
        System.out.println( "El programa se ha ejecutado." );
    }
}
