/*
 *  @(#)Practica5Ejercicio02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de concatenacion.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica5;


public class Practica5Ejercicio02 {

    public static void main ( String args[] ) {

        String s = "Esta podria haber sido una " +
                   "linea muy larga que habria ocupado " +
                   "mas de una linea.";
        System.out.println(s);
    }
}

