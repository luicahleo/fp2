package fp2.poo.practica5.p1;

import fp2.poo.practica5.p1.ClaseBase;
//import fp2.poo.practica5.p1.ClaseDerivadaMismoPaquete;

public class Main {

    public static void main(String args[]){
        ClaseBase b = new ClaseBase();
//        ClaseDerivadaMismoPaquete d = new ClaseDerivadaMismoPaquete ();
    }
}
