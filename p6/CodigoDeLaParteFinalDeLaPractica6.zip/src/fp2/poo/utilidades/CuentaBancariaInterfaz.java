/*
 *  Fichero: Cuenta.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

package fp2.poo.utilidades;
      
import  fp2.poo.pfpooXXX.Titular;
import  fp2.poo.pfpooXXX.NumeroDeCuenta;
import  fp2.poo.pfpooXXX.Saldo;


/**
 * Descripcion: Esta es una clase que representa una cuenta bancaria.
 *              Mantiene una asociacion entre un usuario (de tipo Usuario),
 *              su saldo (de tipo Saldo) y numero de cuenta 
 *              (de tipo NumeroDeCuenta).
 *
 * @version version 1.0 Mayo 2011
 * @author  Fundamentos de Programacion II
 */
public interface CuentaBancariaInterfaz {

    /**
     * Descripcion: Configura el saldo de una cuenta.
     */
    public void            setSaldo (Saldo saldo);

    /**
     * Descripcion: Devuelve el saldo de una cuenta.
     */
    public Saldo           getSaldo();

    /**
     * Descripcion: Configura el numero de cuenta de una cuenta.
     */
    public void            setNumeroDeCuenta (NumeroDeCuenta numeroDeCuenta);

    /**
     * Descripcion: Devuelve el numero de cuenta de una cuenta.
     */
    public NumeroDeCuenta  getNumeroDeCuenta();

    /**
     * Descripcion: Configura el titular de cuenta de una cuenta.
     */
    public void            setTitular (Titular titular);

    /**
     * Descripcion: Devuelve el titular de cuenta de una cuenta.
     */
    public Titular         getTitular();
}
