/*
 *  Fichero: TitularInterfaz.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

package fp2.poo.utilidades;

import  fp2.poo.pfpooXXX.Dni;


/**
 * Descripcion: Esta es una clase que representa un usuario de 
 *              una cuenta bancaria.
 *
 * @version version 1.0 Mayo 2011
 * @author  Fundamentos de Programacion II
 */
public interface TitularInterfaz {

    /*
     *  Descripcion: Metodo de configuracion del atributo nombre.          
     */
    public void setNombre( String nombre );

    /*
     *  Descripcion: Metodo getter de nombre.          
     */
    public String getNombre( );


    /*
     *  Descripcion: Metodo de configuracion del atributo 
     *               relacionado con el primer apellido.          
     */
    public void setPrimerApellido( String primerApellido);

    /*
     *  Descripcion: Metodo getter del primer apellido.          
     */
    public String getPrimerApellido( );

    /*
     *  Descripcion: Metodo de configuracion del atributo 
     *               relacionado con el segundo apellido.          
     */
    public void setSegundoApellido( String segundoApellido);

    /*
     *  Descripcion: Metodo getter del segundo apellido.          
     */
    public String getSegundoApellido( );


    /*
     *  Descripcion: Metodo getter del dni.          
     */
   public void setDni(Dni obj );

    /*
     *  Descripcion: Metodo getter del dni.          
     */
    public Dni getDni( );

    /*
     *  Descripcion: Metodo de configuracion del atributo domicilio.          
     */
    public void  setDomicilio( String domicilio);

    /*
     *  Descripcion: Metodo getter del domicilio.          
     */
    public String getDomicilio( );
}
