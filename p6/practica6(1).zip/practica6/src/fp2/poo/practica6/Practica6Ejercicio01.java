/*
 *  @(#)Practica6Ejercicio01.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de metodo sobrecargado.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;

public class Practica6Ejercicio01 {

    public void metodoSobrecargado() {         
        System.out.println("Sin parametros");
    }

    public void metodoSobrecargado(int a) { 
        System.out.println("Con un parametro entero: " +a);
    }

    public void metodoSobrecargado(int a, int b) { 
        System.out.println("Con dos parametros a y b: practica6 "  + a + " " + b );
    }

    public double metodoSobrecargado(double a) { 
        System.out.println("Con un parametro double: " + a);
        return a * a;
    }

    //public int metodoSobrecargado(int a) { 
    //    System.out.println("Con un parametro entero: " +a);
    //}
}


class Main {
    public static void main( String args[ ]) {
        Practica6Ejercicio01 obj = new Practica6Ejercicio01 ();
        double result = 0.0d;
        obj.metodoSobrecargado(); 
        obj.metodoSobrecargado(10); 
        obj.metodoSobrecargado(10, 20); 
        result = obj.metodoSobrecargado(123.2d);
        System.out.println(" valor devuelto al invocar a obj.metodoSobrecargado(123.2d): " + result );
    }
 }

