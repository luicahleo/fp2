/*
 *  @(#)Practica6Ejercicio02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de sobrecarga.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;


public class Practica6Ejercicio02 {

    public void metodoSobrecargado() {         
        System.out.println("Sin parametros");
    }

    //public void metodoSobrecargado(int a) { 
    //    System.out.println("Con un parametro entero: "+a);
    //}

    public double metodoSobrecargado(double a) { 
        System.out.println("Con un parametro double: "+a);
        return a * a;
    }
}

class Main {
    public static void main( String args[ ]) {
        Practica6Ejercicio02 ob = new Practica6Ejercicio02();
        int i = 88;
        ob.metodoSobrecargado(); 
        ob.metodoSobrecargado(i);     //Esto llama a metodoSobrecargado (double)
        ob.metodoSobrecargado(123.2); //Esto llama a metodoSobrecargado (double)
    }
 }



