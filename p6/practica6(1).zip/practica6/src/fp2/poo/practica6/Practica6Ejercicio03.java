/*
 *  @(#)Practica6Ejercicio03.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se muestra la promocion de tipo que
 *              se puede realizar en las llamadas a metodos polimorficos.
 *              Cada tipo de dato simple contiene su implementacion de 
 *              metodo sobrecargo. Se trata de ver a que tipo promociona
 *              si no existe la version de su metodo.
 *
 *              Este ejemplo necesita volver a compilarlo cada vez que
 *              se realiza la eliminacion de un metodo para probar la
 *              promocion del tipo de dato.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */

package fp2.poo.practica6;

public class Practica6Ejercicio03 {

    public void metodoSobrecargado(byte arg) {         
        System.out.println("Metodo: metodoSobrecargado(byte  obj)");
    }

    public void metodoSobrecargado(short arg) {         
        System.out.println("Metodo: metodoSobrecargado(short obj)");
    }

    public void metodoSobrecargado(int arg) {         
        System.out.println("Metodo: metodoSobrecargado(int obj)");
    }

    public void metodoSobrecargado(char arg) {         
        System.out.println("Metodo: metodoSobrecargado(char obj)");
    }

    public void metodoSobrecargado(long arg) {         
        System.out.println("Metodo: metodoSobrecargado(long obj)");
    }

    public void metodoSobrecargado(float arg) {         
        System.out.println("Metodo: metodoSobrecargado(float obj)");
    }

    public void metodoSobrecargado(double arg) {         
        System.out.println("Metodo: metodoSobrecargado(double obj)");
    }

    public void metodoSobrecargado(boolean arg) {         
        System.out.println("Metodo: metodoSobrecargado(boolean obj)");
    }

}

class Main {
    public static void main( String args[ ]) {
        Practica6Ejercicio03 ob = new Practica6Ejercicio03 ();

       /*
        * Ponga el tipo a la variable arg y elimine el metodo sobrecargado
        * al que se le asociaria.
        */
        XXX  arg = 88;  
        ob.metodoSobrecargado( arg ); 
    }
 }

