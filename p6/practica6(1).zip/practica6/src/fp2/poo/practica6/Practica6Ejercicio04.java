/*
 *  @(#)Saldo.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * Descripcion: Sobrecarga de constructores.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;


public class Practica6Ejercicio04 {
    public static void main (String args[]){
        Saldo obj1 = new Saldo();
        Saldo obj2 = new Saldo(new Double(5e+10));
        Saldo obj3 = new Saldo(20.5d);
        System.out.println("obj1.getSaldo() = " + obj1.getSaldo());
        System.out.println("obj2.getSaldo() = " + obj2.getSaldo());
        System.out.println("obj3.getSaldo() = " + obj3.getSaldo());
    }
}
