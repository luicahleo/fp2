/*
 *  @(#)Practica6Ejercicio05.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * Descripcion: Ejemplo de objeto como parametro.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;

public class Practica6Ejercicio05 {
    public static void main (String args[]){
        Saldo saldo1 = new Saldo( 6000.33d );
        Saldo saldo2 = new Saldo(saldo1);
        System.out.println("saldo1 .getSaldo() = " + saldo1.getSaldo());
        System.out.println("saldo2 .getSaldo() = " + saldo2.getSaldo());
        System.out.println("saldo1 == saldo2   : " + saldo1.igual(saldo2));
    }
}
