/*
 *  @(#)Practica6Ejercicio06.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * Descripcion: Ejemplo de devolucion de objetos.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;

public class Practica6Ejercicio06 {
    public static void main (String args[]){
        Saldo saldo1 = new Saldo( 6000.33d );
        Saldo saldo2 = saldo1.crearCopia();
        System.out.println("saldo1 .getSaldo() = " + saldo1.getSaldo());
        System.out.println("saldo2 .getSaldo() = " + saldo2.getSaldo());
        System.out.println("saldo1 == saldo2   : " + saldo1.igual(saldo2));
    }
}
