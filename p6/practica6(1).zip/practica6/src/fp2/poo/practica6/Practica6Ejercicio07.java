/*
 *  @(#)Practica6Ejercicio07.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Programa que usa el metodo equals y el operador ==.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;

public class Practica6Ejercicio07 {
    public static void main (String args[]){
        for ( int i = 0; i < args.length ; i++) {
            System.out.println("args [" + i + "] : " + args[i]);
        }
    }
}

