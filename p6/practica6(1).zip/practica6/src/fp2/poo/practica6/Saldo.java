/*
 *  @(#)Saldo.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * Descripcion: Sobrecarga de constructores.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica6;


public class Saldo  {

    Double saldo;

    public Saldo() {
        saldo = 0.0d;
    }

    /*
     * Ejemplo de objeto como parametro
     */
    public Saldo(Saldo obj) {
        this.saldo = obj.getSaldo();
    }

    public Saldo(Double d) {
        saldo = d;
    }

    public Saldo(double d) {
        this.saldo = new Double(d);
    }

    public double getSaldo() {
        return this.saldo.doubleValue();
    }

    public void setSaldo(double d) {
        this.saldo = new Double(d);
    }

    /*
     * Ejemplo de objeto como parametro
     */
    public boolean igual (Saldo obj) {
        boolean resultado = false;

        if ( (obj.getSaldo() == this.getSaldo() )) {
            resultado= true;
	 } else {
            resultado= false;
        }
        return resultado;
    }

    /*
     * Ejemplo de devoluci�n de objetos.
     */
    public Saldo crearCopia() {
        return new Saldo(this);
    }
}

