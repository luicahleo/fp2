/*
 *  Fichero: Saldo00.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

package fp2.poo.practica6.javaDoc;

import  fp2.poo.practica6.javaDoc.SaldoInterfaz;


public class Saldo00 implements SaldoInterfaz {

    Double saldo;

    //Hereda comentarios de documentacion
    public Saldo00(Double d) {
        saldo = d;
    }

    //Hereda comentarios de documentacion
    public Saldo00(double d) {
        this.saldo = new Double(d);
    }

    //Hereda comentarios de documentacion
    public double getSaldo() {
        return this.saldo;
    }

    //Hereda comentarios de documentacion
    public Double getSaldoDouble() {
        return this.saldo;
    }

    //Hereda comentarios de documentacion
    public void setSaldo(Double d) {
        this.saldo = d;
    }

    //Hereda comentarios de documentacion
    public void setSaldo(double d) {
        this.saldo = new Double(d);
    }
}
