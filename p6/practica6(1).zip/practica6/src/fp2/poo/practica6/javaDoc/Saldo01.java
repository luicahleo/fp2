/*
 *  @(#)Saldo01.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


package fp2.poo.practica6.javaDoc;

import  fp2.poo.practica6.javaDoc.SaldoInterfaz;

 /**
  * Clase de ejemplo para mostrar el funcionamiento de javadoc.
  * 
  * @author Fundamentos de Programacion II
  * @since  18-Mayo-2011
  * @version 1.0
  */
public class Saldo01 implements SaldoInterfaz {

    Double saldo;

    /**
      * Constructor de Saldo02.
      * 
      * @param d de tipo Double
      * @see Saldo02#Saldo02(double)
      */
    public Saldo01(Double d) {
        saldo = d;
    }

    /**
      * Constructor de Saldo02.
      * 
      * @param d de tipo double
      * @see Saldo02#Saldo02(Double )
      */
    public Saldo01(double d) {
        this.saldo = new Double(d);
    }

     /**
      * Devuelve el saldo.
      * 
      * @return devuelve el saldo como double 
      * @see Saldo02#getSaldoDouble()
      */
   public double getSaldo() {
        return this.saldo;
    }

     /**
      * Devuelve el saldo en un objeto Double.
      * 
      * @return devuelve el saldo como Double
      * @see Saldo02#getSaldo()
      */
    public Double getSaldoDouble() {
        return this.saldo;
    }

     /**
      * Devuelve el saldo en un objeto Double.
      * 
      * @param d de tipo Double.
      * @see Saldo02#getSaldo(double)
      * @throws NullPointerException si el objeto es null.
      */
    public void setSaldo(Double d) throws NullPointerException {
        this.saldo = d;
    }

     /**
      * Devuelve el saldo en un objeto Double.
      * 
      * @param d de tipo double.
      * @see Saldo02#getSaldo(Double)
      */
    public void setSaldo(double d) {
        this.saldo = new Double(d);
    }
}

