/*
 *  @(#)SaldoInterfaz.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

package fp2.poo.practica6.javaDoc;


public interface SaldoInterfaz{

    /**
     * Devuelve el saldo. El valor devuelto es de 
     * tipo double.
     */ 
    public double getSaldo();

    /* 
     * Devuelve el saldo como Double. El valor devuelto es de 
     * tipo Double.
     */ 
    public Double getSaldoDouble();

    /*
     * Configura el saldo. 
     * Se proporciona como parametro un objeto del tipo Double.
     */ 
    public void setSaldo(Double d);

    /*
     * Configura el saldo. 
     * Se proporciona como parametro un double.
     */ 
    public void setSaldo(double d);
}
