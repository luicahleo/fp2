/*
 *  @(#)Circulo.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Implementación de la interfaz Figura para un circulo, heredando de MiFigura
 *
 * @version 1.0 Marzo 2016
 * @author  Fundamentos de Programacion II
 */
package fp2.poo.practica7.utilidades;
import java.awt.Color;
import java.util.*;

public class Circulo extends MiFigura{

	private float diametro;
	private float PI = 3.1416f;
	private Color color;
      
    /**
     * El constructor recibe el diametro y el color de la figura, 
     * como un parametro de tipo Color.
     * @param diametro - tipo float, diametro del circulo
     * @param color - tipo Color de java.awt
     * @see java.awt.Color (https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html)
     */
    public Circulo (float diametro, Color color) { 
         // codigo del constructor
    }

} 

	
