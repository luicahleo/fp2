/*
 *  @(#)CuentaAhorro.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


class CuentaAhorro extends CuentaBancaria {

    private double interes;
    
    public CuentaAhorro (){
        this.interes = 5.0d;
    }

    //Ejemplo de super para Practica7Ejercicio03
    public CuentaAhorro (double saldo){
        super(saldo);
        this.interes = 5.0d;
    }

    public CuentaAhorro (double saldo, double interes){
        super(saldo);
        this.interes = interes;
    }

    public void setInteres(double interes){
        this.interes = interes;
    }

    public double getInteres(){
        return this.interes;
    }
}
