/*
 *  @(#)CuentaBancaria.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 *  
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


public class CuentaBancaria{

    private double saldo; 

    public CuentaBancaria() {
        this.saldo = 0.;
    }

    public CuentaBancaria(double cantidadInicial) {
        this.saldo = cantidadInicial;
    }

    public double getSaldo(){
        return this.saldo;
    }
    public void setSaldo(double saldo){
        this.saldo = saldo;
    }

    public void retirar(double cantidad) throws NoFondosDisponiblesException {
        if( cantidad > 0 ){
            if (saldo >= cantidad) {
                saldo = this.saldo - cantidad;
            } else {
                throw new NoFondosDisponiblesException("No hay suficientes fondos");
            }
        }
    }

    public void depositar(double cantidad){
        if(cantidad > 0){
            this.saldo = this.saldo + cantidad;
        }
    }
}
