/*
 *  @(#)CuentaDeposito.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 *  
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;

/**
 * CuentaDeposito es una cuenta que por defecto si se deposita
 *  mas de 1000 se incrementa el 5% de lo ingresado.
 * Tanto el umbral a partir del cual se aplica el interes, como
 * el interes son configurables en el constructor de la clase.
 */
public class CuentaDeposito extends CuentaAhorro {
    private double minimoAIngresar;
    private double interesIngreso;

    public CuentaDeposito (){
        super( 0.d, .02d );
        this.minimoAIngresar = 1000.0;
        this.interesIngreso  = 5.0;
    }

    public CuentaDeposito (double  minimoAIngresar ){
        super( 0.d, .02d );
        this.minimoAIngresar = minimoAIngresar ;
        this.interesIngreso  = 5.0;
    }

    public CuentaDeposito (double  minimoAIngresar , double interesIngreso  ){
        super( 0.d, .02d );
        this.minimoAIngresar = minimoAIngresar ;
        this.interesIngreso  = interesIngreso  ;
    }

    public void depositar(double cantidad){
        if(cantidad >= this.minimoAIngresar){
            setSaldo( getSaldo() + cantidad + cantidad*this.interesIngreso/100);
        } else {
            super.depositar(cantidad);
        }
    }
}
