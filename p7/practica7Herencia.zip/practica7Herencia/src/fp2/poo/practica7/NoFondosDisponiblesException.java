/*
 *  @(#)NoFondosDisponiblesException.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


public class NoFondosDisponiblesException extends Exception {

    public final static long serialVersionUID = -1L;

    private String informacion;
 
    public NoFondosDisponiblesException(){
    }

    public NoFondosDisponiblesException(String str){
        this.informacion = str;
    }
    
    public String toString(){
        return this.informacion;
    }
}
