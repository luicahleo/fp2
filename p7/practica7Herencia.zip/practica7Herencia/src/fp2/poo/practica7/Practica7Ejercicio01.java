/*
 *  @(#)Practica7Ejercicio01.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de metodo sobrecargado.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;

public class Practica7Ejercicio01 {
    public static void main (String args[]){
        CuentaAhorro   cuentaAhorro   = new CuentaAhorro(); 
        cuentaAhorro.setSaldo(1000.00d);
        System.out.println("Saldo   : " + cuentaAhorro.getSaldo());
        System.out.println("Interes : " + cuentaAhorro.getInteres());
    }
}


