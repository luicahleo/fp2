/*
 *  @(#)Practica7Ejercicio02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de metodo sobrecargado.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;

public class Practica7Ejercicio02 {
    public static void main (String args[]){
        /* 
         * Referencia a la superclase
         */
        CuentaBancaria cuentaBancaria = null; 
        /* 
         * Creacion de un objeto de la subclase
         */
        CuentaAhorro   cuentaAhorro   = new CuentaAhorro(); 
        cuentaAhorro.setSaldo(1000.00d);
        System.out.println("Saldo   : " + cuentaAhorro.getSaldo());
        System.out.println("Interes : " + cuentaAhorro.getInteres());
        /*
         * Variable de la superclase que referencia a un objeto de la subclase
         */
        cuentaBancaria = new CuentaAhorro();  
        System.out.println();
        System.out.println("Saldo   : " + cuentaBancaria.getSaldo());
        /*
         * Variable de la superclase no puede acceder a los miembros a�adidos en la subclase
         */
        //System.out.println("Interes : " + cuentaBancaria.getInteres());
    }
}






