/*
 *  @(#)Practica7Ejercicio02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * 
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


public class Practica7Ejercicio03 {
    public static void main (String args[]){
        /*
         * Llamada con un valor para saldo
         */
        CuentaAhorro   cuentaAhorro1   = new CuentaAhorro(6000.d); 
        System.out.println();
        System.out.println("Saldo   de cuenta 1: " + cuentaAhorro1.getSaldo());
        System.out.println("Interes de cuenta 1: " + cuentaAhorro1.getInteres());
        System.out.println();
        /*
         * Llamada con un valor para saldo e interes
         */
        CuentaAhorro   cuentaAhorro2   = new CuentaAhorro(5000.d, 5.0d); 
        System.out.println("Saldo   de cuenta 2: " + cuentaAhorro2.getSaldo());
        System.out.println("Interes de cuenta 2: " + cuentaAhorro2.getInteres());
    }
}
