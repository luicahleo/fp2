/*
 *  @(#)Saldo.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * Descripcion: Sobrecarga de constructores.
 *
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


public class Practica7Ejercicio04 {
    public static void main (String args[]){
        CuentaDeposito cuenta = new CuentaDeposito ();
        cuenta.depositar(10000.);
        System.out.println("Valor de saldo de la Cuenta Deposito "+cuenta.getSaldo() );
    }
}
