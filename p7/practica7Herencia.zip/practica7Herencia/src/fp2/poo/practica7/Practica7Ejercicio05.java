/*
 *  @(#)Practica7Ejercicio05.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;

public class Practica7Ejercicio05 {
    public static void main (String args[]){
        /*
         * Referencia a la superclase
         */
        CuentaBancaria referenciaACuenta = null;
        /*
         * Objeto del tipo CuentaDeposito (subclase) 
         */
        CuentaDeposito cuentaDeposito = new CuentaDeposito();
        /*
         * Objeto del tipo CuentaBancaria (superclase) 
         */
        CuentaBancaria cuentaBancaria = new CuentaBancaria ();

        System.out.println("depositar en CuentaBancaria");
        referenciaACuenta= cuentaBancaria;
        referenciaACuenta.depositar(5000.);
        System.out.println(referenciaACuenta.getSaldo()); 

        System.out.println();
        System.out.println("depositar en CuentaDeposito ");
        referenciaACuenta= cuentaDeposito;
        referenciaACuenta.depositar(5000.);
        System.out.println(referenciaACuenta.getSaldo()); 

    }
}
