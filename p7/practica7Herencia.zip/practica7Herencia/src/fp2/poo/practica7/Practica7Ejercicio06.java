/*
 *  @(#)Practica7Ejercicio06.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */

/**
 * version 1.0 Mayo 2011
 * Fundamentos de Programacion II
 */
package fp2.poo.practica7;


public interface Practica7Ejercicio06 {
    public final static int VALOR_MAXIMO = 100;
}
class Main{
    public static void main (String args[]){
        System.out.println("Valor de Practica7Ejercicio06.VALOR_MAXIMO :"
                           + Practica7Ejercicio06.VALOR_MAXIMO );
    }
}
