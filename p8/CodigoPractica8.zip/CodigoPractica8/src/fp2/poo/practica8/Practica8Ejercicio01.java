/*
 *  @(#)Practica8Ejercicio01.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se realiza la lectura de bytes de la entrada est�ndar.
 *
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.InputStream;
import java.io.IOException;

public class Practica8Ejercicio01 {
    public static void main(String args[]){
       InputStream in   = null;
       int cr           = 0;
       int total   = 0;
       int espacio = 0;
       
       try{
           in = System.in;
           
           System.out.println("Introduccion de datos desde la entrada estandar.");
           System.out.println("Introduzca datos y pulse la tecla ENTER.");
           System.out.println("La lectura de datos finaliza cuando se pulsa con el caracter 'q'.");
           
           for(total = 0; (cr = in.read()) != 'q' ; total++){
               if(Character.isWhitespace((char)cr))
                   espacio++;
           }
           
           in.close();
           System.out.println(total + " caracteres, "  + espacio + " espacios");
      }catch(IOException e){
         System.out.println(e);
      }
    }
}

