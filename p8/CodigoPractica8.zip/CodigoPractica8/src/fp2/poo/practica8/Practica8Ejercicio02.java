
/*
 *  @(#)Practica8Ejercicio02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se realiza la lectura de bytes de la entrada est�ndar.
 * Es el mismo caso que el de Practica8Ejercicio01.java, pero en este caso el flujo de
 * entrada se "envuelve" en un flujo de tipo InputStreamReader para realizar la
 * conversion de 8 a 16 bits.
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.InputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Practica8Ejercicio02 {
    public static void main(String args[]){
       InputStreamReader in   = null;
       int cr           = 0;
       int total   = 0;
       int espacio = 0;
       
       try{
           in = new InputStreamReader(System.in);

           System.out.println("Introduccion de datos desde la entrada estandar.");
           System.out.println("Introduzca datos y pulse la tecla ENTER.");
           System.out.println("La lectura de datos finaliza cuando se pulsa con el caracter 'q'.");
           
           for(total = 0; (cr = in.read()) != 'q' ; total++){
               if(Character.isWhitespace((char)cr))
                   espacio++;
           }
           
           in.close();
           System.out.println(total + " caracteres, "  + espacio + " espacios");
      }catch(IOException e){
         System.out.println(e);
      }
    }
}

