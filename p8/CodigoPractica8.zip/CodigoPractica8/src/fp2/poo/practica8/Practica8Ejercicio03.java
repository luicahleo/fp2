/*
 *  @(#)Practica8Ejercicio03.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de uso de FileInputStream.
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *  Recuenta el numero de bytes de un fichero.
 *  Se proporciona el nombre como argumento en 
 *  linea de comandos. Sino se proporciona fichero se lee 
 *  de la entrada est�ndar (System.in) 
 */
public class Practica8Ejercicio03 {
    public static void main( String args[] ) {

      InputStream in = null;
      int total      = 0;

      try{
         if(args.length == 0){
            in = System.in;
        }else{
            in = new FileInputStream(args[0]);
        }
        int c = 0;
        
        while( (c = in.read()) != -1 ) {
            System.out.write((char)c);
            total++;
        }
        in.close();    
        System.out.println("Numero total de caracteres leidos: " + total);
      }catch(FileNotFoundException e){
          System.out.println("fichero no encontrado "+e);
      }catch(IOException e){
          System.out.println(e);
      }
    }
}
