
/*
 *  @(#)Practica8Ejercicio04.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion:
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class Practica8Ejercicio04 {

   public static void main(String[] args) {
      byte[] b = {'F', 'u', 'n', 'd', 'a','m', 'e', 'n', 't', 'o','s',' ',
                  'd','e',' ',
                  'P', 'r', 'o', 'g', 'r', 'a', 'm', 'a', 'c', 'i', 'o', 'n', ' ',
                  'I', 'I', '\n'};
      OutputStream os = null;
      try {
         os = new FileOutputStream(args[0]);
         for (int i = 0; i < b.length; i++) {
            os.write(b[i]);
            System.out.print("" + (char)b[i]);
         }
          os.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }
   }
}
