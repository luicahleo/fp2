
/*
 *  @(#)Practica8Ejercicio05.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se realiza la lectura de bytes de la entrada est�ndar.
 *
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileOutputStream;

public class Practica8Ejercicio05 {
    public static void main(String args[]){
       InputStream  in   = null;
       OutputStream out   = null;      
       int cr            = 0;
       
       try{
           in  = System.in;
           out = new FileOutputStream(args[0]);
          
           for( ; (cr = in.read()) != -1 ;  ){
              out.write((byte)cr);
              System.out.print("" + (char)cr);
         }
          out.close();
          in.close();
      } catch ( IOException e ) {
         e.printStackTrace();
      }
   }
}
