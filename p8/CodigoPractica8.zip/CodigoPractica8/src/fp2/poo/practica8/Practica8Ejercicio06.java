/*
 *  @(#)Practica8Ejercicio06.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripci�n: Copia de un fichero a otro.
 *
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.Reader;

public class Practica8Ejercicio06 {
    public static void main(String[] args) {
   
        try {
            InputStream  in = new FileInputStream( args[0]);
            OutputStream os = new FileOutputStream(args[1]);
            int          cr = 0;

            System.out.println("Se han abierto los dos ficheros " + args[0] + " y " + args[1] );
            System.out.println("Comienza la copia de un fichero en otro. ");

            while((cr = in.read()) != -1 ) {
                System.out.print("" + (char) cr);
                os.write((byte)cr);
            }
            in.close();
            os.close();
        } catch ( FileNotFoundException e) { 
            System.err.println("Fichero no encontrado");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
   }
}

