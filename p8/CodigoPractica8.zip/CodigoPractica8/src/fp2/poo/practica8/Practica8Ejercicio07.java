/*
 *  @(#)Practica8Ejercicio07.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripci�n: Uso de un flujo buferado de un fichero.
 *
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.Reader;

public class Practica8Ejercicio07 {
    public static void main(String[] args) {
        FileInputStream     fin   = null;
        BufferedInputStream bis   = null;  
        int                 c     = 0;
        
        try {
            if ( args.length == 1 ){

                fin = new FileInputStream(args[0]);
                bis = new BufferedInputStream(fin);   
         
                while ( ( c = bis.read()) != -1 ) {
                    System.out.print( (char)c );
                }
                fin.close();
                bis.close();
            } else {
                System.err.println("Proporcione el nombre del fichero.");
            }     
        } catch (FileNotFoundException e) {
            System.err.println(e);
        } catch (IOException e) {
            System.err.println(e);
        } catch (Exception e) {
            System.err.println(e);
        }
     }
 } 
 






