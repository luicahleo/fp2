/*
 *  @(#)Practica8Ejercicio08.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripci�n: Uso de un flujo buferado de un fichero.
 *
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Practica8Ejercicio08 {
    public static void main(String[] args) {
      
        FileInputStream       is    = null;
        BufferedInputStream   bis   = null;
        BufferedOutputStream  bos   = null;
        FileOutputStream      os    = null;
        
 		int                   value = -1;
		
        try{    
            is   = new FileInputStream( args[0] );
            bis  = new BufferedInputStream(is);
            
            os = new FileOutputStream ( args[1] );
            bos  = new BufferedOutputStream(os);
		
            while ((value = bis.read()) != -1) {
                bos.write(value);
            }

            /* Invoca a flush para forzar que los bytes se escriban en el flujo. */
            bos.flush();  
      }catch(IOException e){
         // if any IOException occurs 
         e.printStackTrace();        
      }finally{
          try{
              if(is!=null)
                  is.close();
              if(bis!=null)
                  bis.close();
              if(os!=null)
                  os.close();                           
              if(bos!=null)
                  bos.close();
          }catch(IOException e){
             // if any IOException occurs 
             e.printStackTrace();
          }
      }	
   }
}



