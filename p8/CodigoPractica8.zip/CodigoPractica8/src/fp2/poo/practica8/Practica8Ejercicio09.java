/*
 *  @(#)Practica8Ejercicio09.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: 
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */

package fp2.poo.practica8;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *  Programa que copia su entrada en su salida,
 *  transformando un valor particular en otro.
 *  Con valores proporcionados desde linea de comandos.
 */
public class Practica8Ejercicio09 {
    public static void main( String args[] ) {

      try{
          byte desde = (byte)args[0].charAt(0);
          byte hacia = (byte)args[1].charAt(0);
          int b  = 0;

          while( (b = System.in.read()) != -1)
              System.out.write( (b == desde) ? hacia : b);
			  
      }catch(IOException e){
          System.out.println(e);
      }catch(IndexOutOfBoundsException e){
          System.out.println(e);
      }
    }
}
