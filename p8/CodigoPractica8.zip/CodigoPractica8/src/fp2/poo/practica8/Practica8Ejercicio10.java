/*
 *  @(#)Practica8Ejercicio10.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: 
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */


package fp2.poo.practica8;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 *  Un flujo Pushback nos permite enviar de vuelta  
 *  cuando la aplicaci�n lo requiera. 
 *  Pushback es generalmente �til para dividir la entrada en tokens. 
 *  Por ejemplo, los exploradores l�xicos a menudo s�lo saben que un token  
 *  ha terminado (como por ejemplo un identificador) cuando leen el primer
 *  car�cter que lo sige. Una vez visto ese car�cter, el explorador debe 
 *  devolverlo al flujo de entrada, para que quede disponible como el 
 *  primer car�cter del siguiente token.
 *
 *  Este ejercicio usa un flujo PushbackInputStream para indicar la secuencia 
 *  consecutiva m�s larga con el mismo byte de entrada. 
 * Los resultados los muestra por pantalla.
 */
import java.io.IOException;
import java.io.PushbackInputStream;

public class Practica8Ejercicio10 {
    public static void main(String[] args) throws IOException{
        PushbackInputStream in =  new PushbackInputStream (System.in);
        int max = 0;   // secuencia m�s larga encontrada
        int maxB= -1;  // el byte de esa secuencia
        int b;         // byte actual de la entrada
        
        do{
            int cnt;
            int b1 = in.read();   // primer byte de la secuencia
            for(cnt = 1; (b = in.read()) == b1 ; cnt++)
                ;
            if(cnt > max){
                max = cnt;   //recuerda la longitud
                maxB= b1;    //recuerda el valor del byte
            }
            in.unread(b);    //devuelve el inicio de la seguiente sec.
        }while(b != -1);     //hasta el final de la entrada.
        System.out.println(max + " bytes de " + (char)maxB);
        in.close();
    }
}


