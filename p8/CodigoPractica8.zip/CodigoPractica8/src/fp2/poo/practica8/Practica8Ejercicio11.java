/*
 *  @(#)Practica8Ejercicio11.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: 
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */
package fp2.poo.practica8;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.Reader;

public class Practica8Ejercicio11 {
    public static void main(String args[]){
       Reader in   = null;
       int cr      = 0;
       int total   = 0;
       int espacio = 0;
      try{

       if( args.length == 0){
           in = new InputStreamReader(System.in);
       }else{
           in = new FileReader(args[0]);
       }
       for(total = 0; (cr = in.read()) != -1 ; total++){
           if(Character.isWhitespace((char)cr))
               espacio++;
       }
       in.close();
       System.out.println(total + " caracteres, "  + espacio + " espacios");
      }catch(FileNotFoundException e){
         System.out.println(e);
      }catch(IOException e){
         System.out.println(e);
      }
    }
}

