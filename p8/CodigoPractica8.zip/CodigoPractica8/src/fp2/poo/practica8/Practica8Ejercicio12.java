/*
 *  @(#)Practica8Ejercicio12.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: 
 *
 * version 1.0 Mayo 2014
 * Fundamentos de Programacion II
 */
package fp2.poo.practica8;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.Writer;

public class Practica8Ejercicio12 {
    public static void main(String args[]){
        InputStream       inp  = null;
        InputStreamReader in   = null;        
        Writer            out  = null;      
        int               cr   = 0;

        try{
            inp  = System.in;
            out = new FileWriter( args[0] );
            in  = new InputStreamReader(System.in);
                     
            for( ; (cr = in.read()) != -1 ;  ){
                out.write((byte)cr);
                System.out.print("" + (char)cr);
            }
            out.close();
            in.close();
        } catch ( IOException e ) {
            e.printStackTrace();
        } 
    }
}

