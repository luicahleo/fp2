/*
 *  @(#)Bolsa.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase Bolsa contiene un atributo de tipo Object.
 *              No se hace uso de genéricos.
 *              Uso de cast.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Bolsa{
    private Object objeto;
    public void agrega(Object objeto) {
      this.objeto = objeto;
    }
    public Object obtiene() {
         return objeto;
    }
}

