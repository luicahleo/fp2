/*
 *  @(#)Caja.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase Caja contiene un tipo genérico.
 *              
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

/**
 * Version con Genericos de la clase Caja. 
 */
public class Caja<T> {

    private T objeto; 

    /** Constructor sin parámetros. 
     *  El constructor está sobrecargado.
     */
    public Caja( ){
        this.objeto = null;
    }
    
    /** Constructor con un parámetro.
     *  El constructor está sobrecargado.
     */
    public Caja( T objeto ){
        this.objeto = objeto;
    }

    /** Metodo para añadir un objeto. */
    public void agrega(T objeto) {
        this.objeto = objeto;
    }

    /** Metodo para obtener el objeto. */
    public T obtiene() {
        return objeto;
    }
}

