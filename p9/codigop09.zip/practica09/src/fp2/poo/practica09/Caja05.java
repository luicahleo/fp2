/*
 *  @(#)Caja05.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase Caja05 contiene un constructor con un genérico.
 *              También se usa un método con un tipo genéricos.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja05 {

    public  Caja05 () {
      System.out.println("Constructor Caja05 sin parametros");	
    }	

    public <T> Caja05 ( T tipo ) {
      System.out.println("\nConstructor Caja05 con parametros");	
      System.out.println("Tipo y su valor: " + tipo.getClass().getName() +"\t"+ tipo  +"\n");
	}	

    public <U> void metodoConGenericos( U parametro ){
      System.out.println("Tipo y su valor: " + parametro.getClass().getName() +"\t"+ parametro);
    }
	
    public static  <M> void metodoConGenericosEstatico( M variable ){
      System.out.println("Tipo y su valor: " + variable.getClass().getName() +"\t"+ variable);
    }	
}
