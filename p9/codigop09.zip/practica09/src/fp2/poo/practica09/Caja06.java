/*
 *  @(#)Caja06.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase soporte para el ejemplo 6.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja06<T>{

    private T t;          

    public void agrega(T t) {
        this.t = t;
    }

    public T obtiene() {
        return t;
    }
}



