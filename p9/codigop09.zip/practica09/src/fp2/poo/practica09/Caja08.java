/*
 *  @(#)Caja08.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase soporte para el ejemplo 8.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja08<T>{
    
    private static T atributoPrivado;
	
    private T objeto; 

    public Caja08( ){
        this.objeto = null;
    }
    
    public Caja08( T objeto ){
        this.objeto = objeto;
    }

    public void agrega(T objeto) {
        this.objeto = objeto;
    }

    public T obtiene() {
        return objeto;
    }
}

