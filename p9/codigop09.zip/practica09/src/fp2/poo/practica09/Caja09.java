/*
 *  @(#)Caja09.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase soporte para el ejemplo 9.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja09<T>{
    
    private T objeto; 

    public Caja09( ){
        this.objeto = null;
    }

    public void agrega(T objeto) {
        this.objeto = objeto;
    }

    public T obtiene() {
        return objeto;
    }
}

