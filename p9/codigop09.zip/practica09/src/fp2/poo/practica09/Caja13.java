/*
 *  @(#)Caja13.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: La clase para mostrar un ejemplo con excepciones.
 *              No se hace uso de genéricos.
 *              Uso de cast.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Caja13<T  extends Exception> {
    private Integer matriz [];

	
    public void get() throws T { 
	    // Hacer algo... 
		matriz[0]= 1;
	}
}

