/*
 *  @(#)Caja14.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Clase Caja15 se usa como soporte para el ejemplo 15.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja14<T> {
    private T objeto; 

    public Caja14( T objeto ){
        this.objeto = objeto;
    }	
	
    public void agrega(T objeto) {
        this.objeto = objeto;
    }	

    public T obtiene() {
        return objeto;
    }
}


