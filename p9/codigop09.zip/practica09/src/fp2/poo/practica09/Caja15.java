/*
 *  @(#)Caja15.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Clase Caja15 se usa como soporte para el ejemplo 15.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Caja15<T>{
    /** Variable genérica */
    private T t;

    /** Constructor */          
    public  Caja15(T t){
      this.t = t;
      //System.out.println("T: " + t.getClass().getName());
    }

    /** Método que asigna un nuevo objeto */
    public void agrega(T t) {
       this.t = t;
    }
    
    /** Método que obtiene el objeto almacenado */
    public T obtiene() {
        return t;
    }
}

