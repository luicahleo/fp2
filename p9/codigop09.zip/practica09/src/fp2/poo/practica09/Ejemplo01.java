/*
 *  @(#)Ejercicio01.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Primer ejemplo. Sin uso de Genericos.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo01 {
    public static void main(String[] args){
        // SOLO objetos Integer en Bolsa!
        Bolsa cajaDeInteger = new Bolsa();
        cajaDeInteger.agrega(new Integer(10)); //Linea a comentar
        //cajaDeInteger.agrega(new String("10"));
		/* Con el cast */
        Integer unInteger = (Integer)cajaDeInteger.obtiene();        
		/* Sin el cast */
        //Integer unInteger =  cajaDeInteger.obtiene();
        System.out.println(unInteger);
    }
}
