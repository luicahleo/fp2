/*
 *  @(#)Ejemplo02.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo de muestra el uso basico de una clase con genericos.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo02 {
    public static void main ( String[] args ) {    
        /* Se crea un objeto Caja especificando como el tipo "String"   */
        Caja<String> caja01DeString = null; /* Declaracion de la variable*/
        caja01DeString = new Caja<String>(); /* Construccion del obj.    */
        caja01DeString.agrega("Fundamentos de Programación II"); /* Uso.*/
        System.out.println(caja01DeString.obtiene());        
        
        Caja<String> caja02DeString = null;
        caja02DeString = new Caja<String>("Fundamentos de Programación II");
        System.out.println(caja02DeString.obtiene());        
        
        /* Se crea un objeto Caja especificando como el tipo "Integer" */
        Integer unEntero = null;
        unEntero = new Integer(2);
        Caja<Integer> cajaDeInteger = new Caja<Integer>();
        cajaDeInteger.agrega(unEntero);
        System.out.println("Fundamentos de Programación "+cajaDeInteger.obtiene());        



    }
}

