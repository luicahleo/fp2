/*
 *  @(#)Ejemplo03.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se muestra el uso de basico de genericos.
 *              
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo03 {
    public static void main(String[] args) {

        // SOLO objetos Integer en Caja!
        Caja<Integer> cajaInteger = null;
        cajaInteger = new Caja<Integer>();

		
		    // Se intenta agregar un objeto de tipo String
        cajaInteger.agrega("10"); // es un String
    
        //cajaInteger.agrega(new Integer(10));
        System.out.println(cajaInteger.obtiene());
    }
}


