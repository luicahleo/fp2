/*
 *  @(#)Ejemplo04.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se muestra el uso de varios tipos genericos en una clase. 
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo04{
    public static void main (String args[]){
	    Pareja<String,Integer> par = new Pareja<String,Integer>("cadena",new Integer(1));
		System.out.println("Parametro primero: " + par.getPrimero());
		System.out.println("Parametro segundo: " + par.getSegundo());
        par.setPrimero("cambio cadena");		
		par.setSegundo(new Integer(21));
		System.out.println("Parametro primero: " + par.getPrimero());
		System.out.println("Parametro segundo: " + par.getSegundo());
	}
}
