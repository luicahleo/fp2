/*
 *  @(#)Ejemplo05.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se muestra el uso de metodos con tipos genericos. 
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;
public class Ejemplo05 {
    public static void main( String args[] ){
	  Caja05 ref01 = new Caja05(); 
	  Caja05 ref02 = new <Long>Caja05(new Long(10L)); 
	  
	  //Caja05<Long> ref01 = new Caja05<Long>(); 
	  //Caja05<Long> ref02 = new <Long>Caja05<Long>(new Long(10L)); 
	  
    System.out.println("Sin metodo estático.\n");
	  ref01.<String> metodoConGenericos( "Fundamentos de Programacion II");
	  ref01.<Integer>metodoConGenericos( new Integer( 10)   );	  
	  ref01.<Double> metodoConGenericos( new Double ( 10.0) );	 

    System.out.println();
    System.out.println("Con metodo estático.\n");

	  Caja05.<String> metodoConGenericosEstatico( "Fundamentos de Programacion II");
	  Caja05.<Integer>metodoConGenericosEstatico( new Integer( 10)   );	  
	  Caja05.<Double> metodoConGenericosEstatico( new Double ( 10.0) );	 
 	  
    }
}
