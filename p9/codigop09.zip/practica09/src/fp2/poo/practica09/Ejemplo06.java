/*
 *  @(#)Ejemplo06.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se muestra que no se puede usar tipos de datos 
 *              simple para proporcionarlos a las clases genericas.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Ejemplo06 {
    public static void main(String[] args) {
	    // El uso de genéricos con tipos de datos simples
		// no está permmitido.
		// Estos ejemplos generarán error en compilación.
/*
        Caja06<int>    caja01  = new Caja06<int>();
        Caja06<long>   caja02 = new Caja06<long>();		
        Caja06<float>  caja03 = new Caja06<float>();
        Caja06<double> caja04 = new Caja06<double>();
*/

		// Estos ejemplos NO generarán error en compilación.
        Caja06<Integer> caja01  = new Caja06<Integer>();
        Caja06<Long>    caja02 = new Caja06<Long>();		
        Caja06<Float>   caja03 = new Caja06<Float>();
        Caja06<Double>  caja04 = new Caja06<Double>();
		
        caja01.agrega(new Integer (1));
        caja02.agrega(new Long    (2L));
        caja03.agrega(new Float   (3.f));
        caja04.agrega(new Double  (4.d));    
		
		System.out.println(caja01.obtiene());
		System.out.println(caja02.obtiene());
		System.out.println(caja03.obtiene());
		System.out.println(caja04.obtiene());		
    }
}
