/*
 *  @(#)Ejemplo07.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Esta clase hace uso de la instanciación de un tipo genérico.
 *              La compilación de esta clase genera un error en compilación.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo07 {
    public static void main(String[] args) {
	    Ejemplo07.metodo();
    }
    public static <E> void metodo() {
        E elem = new E();  // error en compilacion 
    }	
}
