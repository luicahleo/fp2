/*
 *  @(#)Ejemplo07a.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Este fichero contiene tres clase.
 *              Ejemplo07a que contiene el metodo main para probar la ejecución.
 *              Caja07a<T> que contiene un generico y permite instanciar un generico.
 *              Tipo es la clase que se usa para pasar como generico.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Caja07a<T>{
    private Class<T> clazz;

    public Caja07a(Class<T> clazz){
        this.clazz = clazz;
    }

    public T buildOne() throws InstantiationException, IllegalAccessException{
        return clazz.newInstance();
    }
}

/* 
 * Esta clase se va a utilizar par proporcionar el tipo 
 * que se le proporciona a una clase que usa genéricos
 */
class Tipo{
    public Tipo(){
        System.out.println("Construccion de la clase Tipo");
    }
}

public class Ejemplo07a {   
    public static void main(String [] args) throws Exception {
        Caja07a<Tipo> x = new Caja07a<Tipo>(Tipo.class);
        Tipo y = x.buildOne();
		
        Caja07a<Tipo> x1 = new Caja07a<Tipo>(Tipo.class);
        Tipo z = x.buildOne();		
    }
}
