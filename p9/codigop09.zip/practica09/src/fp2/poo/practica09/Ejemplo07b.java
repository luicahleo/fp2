/*
 *  @(#)Ejemplo07b.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Este fichero proporciona una versión alternativa a el ejemplo Ejemplo07a.
 *              Este ejemplo usa una interfaz que se implementa en una clase statica interna a Tipo.
 *              Este mecanismo se usa para instanciar un objeto del tipo Tipo.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Caja07b<T> {
    private T var;

    Caja07b(Factory<T> fact) {
        System.out.println("Constructor con el parametro Factory<T>\n");
        var = fact.factory();
    }
	
    Caja07b(T var) {
        System.out.println("Constructor con el parametro T \n");
        this.var = var;
    }
	
    T get() { 
	    return var; 
	}
}

interface Factory<T> {
    T factory();
}

class Tipo {
    //Clase static interna para la implementacion de Factory<T> 
    public static class TipoFactory implements Factory<Tipo> {
        public Tipo factory() {
            return new Tipo();
        }
    }
    public String toString() { 
	    return "Tipo.toString()"; 
	}
}

public class Ejemplo07b {
    public static void main(String[] string) {
        Caja07b<Tipo> gen = new Caja07b<Tipo>(new Tipo.TipoFactory());
        System.out.print(gen.get());
    }
}
