/*
 *  @(#)Ejemplo09.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de uso del operador instanceof con genéricos.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo09 {
    public static void main(String[] args)throws Exception  {
        Caja09<Integer> ref = new Caja09<Integer>();
        //if(ref instanceof Caja09<Integer> ) {
		    //    System.out.println("Error en compilacion...");
		    //}
        if(ref instanceof Caja09<?> ) {
		    System.out.println("No hay error en compilacion...");
		}		
    }	    
}
	

