/*
 *  @(#)Ejemplo10.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de uso de instanciación de una matriz a partir de tipos parametrizados. 
 *              Este ejemplo contiene un error en compilación.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo10 {
    public static void main(String[] args)throws Exception  {
        Caja10<Integer> ref [] = new Caja10<Integer>()[10];
    }	    
}
	

