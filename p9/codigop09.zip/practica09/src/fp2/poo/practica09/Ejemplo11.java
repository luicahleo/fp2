/*
 *  @(#)Ejemplo11.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Ejemplo de uso de Excepciones con genericos. 
 *              Este ejemplo contiene un error en compilación.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class ExcepcionConGenericos<T> extends Exception { 
    // error en compilacion
    /* Hacer algo... */ 
}    

public class Ejemplo11 {
    public static void main(String[] args)throws Exception  {

    }	    
}
	

