/*
 *  @(#)Ejemplo13.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En ese ejemplo se presenta el uso de excepciones con genéricos. 
 *              
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class Ejemplo13 {
    public static void main(String[] string) {
        Caja13<NullPointerException> obj = new Caja13<NullPointerException>();
		try {
            obj.get();
	    } catch (NullPointerException e) {
		    //Geston de la excepcion
			System.out.println("Excepcion capturada");
		}
    }
}
