/*
 *  @(#)Ejemplo14.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En este ejemplo se presenta la sobrecarga con tipos clases que 
 *              usan tipos genéricos.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Utilidades {
	public static void imprime(Caja14<Integer> c){
	    System.out.println(c.obtiene());
	}
	
	//public static void imprime(Caja14<String> c){
	//    System.out.println(c.obtiene());
	//}	
}

public class Ejemplo14 {
    public static void main(String[] string) {
        Caja14<Integer> obj = new Caja14<Integer>(new Integer(7));	
		    Utilidades.imprime( obj );
    }
}
