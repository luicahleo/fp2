/*
 *  @(#)Ejemplo15.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Esta clase contiene el metodo main para probar el ejemplo 15,
 *              donde se prueba el uso del wildcard.
 *
 *     
 *      Caja15<?> obj = new Caja15<Integer>(new Integer(7));		
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

class Ejemplo15 {
    public static void main(String[] string) {
        Caja15<?> obj = new Caja15<Integer>(new Integer(7));	
		    System.out.println(obj.obtiene());
    }
}

