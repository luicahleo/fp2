/*
 *  @(#)Ejemplo16.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: Esta clase contiene el metodo main para probar el ejemplo 16.
 *              En este ejemplo se pone de manifiesto el error que se produce
 *              al asignar variables declaradas con genéricos diferentes:
 *
 *     Caja16<? extends Number> obj3 = new Caja16<Long>(new Long(10L));	
 *     Caja16<? super   String> obj4 = new Caja16<String>(new String());	
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
 package fp2.poo.practica09;

public class Ejemplo16 {
    public static void main (String args[]){
     Caja16<Integer> obj1 = new Caja16<Integer>();
     Caja16<Integer> obj2 = new Caja16<Integer>(new Integer(12));		
     System.out.println("Valor :" + obj1.obtiene());
     System.out.println("Valor :" + obj2. obtiene ());
     obj1.agrega(new Integer(15));
     System.out.println("Valor :" + obj1. obtiene ());

     Caja16<? extends Number> obj3 = new Caja16<Long>(new Long(10L));	
     Caja16<? super   String> obj4 = new Caja16<String>(new String());	
     obj3 = obj1;	
     //obj3 = obj4; //ERROR
    }
}

