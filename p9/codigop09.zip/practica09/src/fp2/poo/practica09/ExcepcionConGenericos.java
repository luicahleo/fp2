/*
 *  @(#)ExcepcionConGenericos.java
 *
 *  Fundamentos de Programacion II. GITT.
 *  Departamento de Ingenieria Telematica
 *  Universidad de Sevilla
 *  
 */


/**
 * Descripcion: En esta clase se declara un excepción.
 *              Genera un error en compilación ya que no está permitido.
 *
 * version 1.0 Mayo 2016
 * Fundamentos de Programacion II
 */
package fp2.poo.practica09;

public class ExcepcionConGenericos<T> extends Exception { 
    // error en tiempo de compilacion 
    /* ... */ 
}    
