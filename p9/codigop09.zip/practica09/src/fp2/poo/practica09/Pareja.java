package fp2.poo.practica09;

public class Pareja<X,Y>  { 
  private X primero;
  private Y segundo;

  public Pareja(X a1, Y a2) {
    this.primero  = a1;
    this.segundo  = a2;
  }
  public X getPrimero()  { 
     return this.primero; 
  }
  public Y getSegundo() { 
     return this.segundo; 
  }
  public void setPrimero(X arg) { 
     this.primero = arg; 
  }
  public void setSegundo(Y arg) { 
     this.segundo = arg; 
  }
} 