package fp2.poo.practica09;

public class ThrowableConGenericos<T> extends Throwable { 
    /* ... */ 
	// error en tiempo de compilacion
}	